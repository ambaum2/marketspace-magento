<?php

/**
 * PACKT News Model
 *
 * @category   PACKT
 * @package    PACKT_News
 * @author     Nurul Ferdous <ferdous@dynamicguy.com>
 */
class Dwg_Adminneworder_Model_Sales_Observer extends Mage_Core_Model_Abstract
{

    public function _construct()
    {
        parent::_construct();
        $this->_init('adminneworder/adminneworder');
    }
    public function newOrderCreateAdmin($observer)
    {
    	$emailTemplate  = Mage::getModel('core/email_template')->loadByCode("contact_form");
    	$emailTemplateVariables['fullname'] = "test sales observer";
        $emailTemplate->setSenderName("Escape Locally");
        $emailTemplate->setTemplateSubject("Thank you for your interest in our experience packages");
        $emailTemplate->setSenderEmail("experience@escapelocally.com");
        $emailTemplate->setReturnPath("admin@escapelocally.com");
	$emailTemplate->send("ambaum2@gmail.com", "Alan Test",$emailTemplateVariables); 
	$event = $observer->getEvent();
	$contactAdd = Mage::getModel('contact/contact');
	$contactAdd->setSalesId(1)->setOrderId(2)->setExpMakerId(3);
	$contactAdd->save();

   }
}
