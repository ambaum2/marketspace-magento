<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
create table tablename(tablename_id int not null auto_increment, name varchar(100), primary key(tablename_id));
    insert into tablename values(1,'tablename1');
    insert into tablename values(2,'tablename2');
		
SQLTEXT;

$installer->run($sql);
$installer->addAttribute("catalog_product", "ms_member_deals_limit",  array(
    "type"     => "int",
    "backend"  => "",
    "frontend" => "",
    "group"    => "",
    "label"    => "Deals Limit",
    "input"    => "text",
    "class"    => "",
    "source"   => "",
    "global"   => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
    "visible"  => true,
    "required" => false,
    "user_defined"  => true,
    "default" => "1",
    "searchable" => false,
    "filterable" => false,
    "comparable" => false,
	
    "visible_on_front"  => false,
    "unique"     => false,
    "note"       => "The shipping cost if you filled out epr product, per order, or per product by weight above"

	));
$installer->endSetup();
	 